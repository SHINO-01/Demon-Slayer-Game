int forwardMovementImage[8];
int demoBackgroundImage;
int standDemo;
void loadImage(){
	//forward movement images
	forwardMovementImage[0] = iLoadImage("images\\fw01.png");
	forwardMovementImage[1] = iLoadImage("images\\fw02.png");
	forwardMovementImage[2] = iLoadImage("images\\fw03.png");
	forwardMovementImage[3] = iLoadImage("images\\fw04.png");
	forwardMovementImage[4] = iLoadImage("images\\fw05.png");
	forwardMovementImage[5] = iLoadImage("images\\fw06.png");
	forwardMovementImage[6] = iLoadImage("images\\fw07.png");
	forwardMovementImage[7] = iLoadImage("images\\fw08.png");

	//backgorund images
	demoBackgroundImage = iLoadImage("images\\demoBackground.jpg");

	//Stand image
	standDemo = iLoadImage("images\\standDemo.png");
}