#ifndef PLAYERMOVEMENTVARIABLESIMAGES_H_
#define PLAYERMOVEMENTVARIABLESIMAGES_H_
/*
void showForwardMovementImage(){
	for (int i = 0; i < 8;i++)
		iShowImage(0, 0, 171, 180, forwardMovementImage[i]);
}
*/
//Variables for movements (How much distance ie coordinates will go or back)
int dx = 10;
int dy = 10;
//Variables for movements (current position)
int playerCoordX = 0;
int playerCoordY = 200;
int playerIndex = 0;//

//counters and bolleans for necessary conditions
bool standPosition = true;

//checkings
bool clickedRight = false;
bool clickedLeft = false;

#endif // !PLAYERMOVEMENTVARIABLESIMAGES_H_