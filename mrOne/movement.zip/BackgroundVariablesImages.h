#ifndef BACKGROUNDVARIABLESIMAGES_H_
#define  BACKGROUNDVARIABLESIMAGES_H_

void showBackgroundImage(){
	iShowImage(0, 0, 1280, 720, demoBackgroundImage);
}


#endif // BACKGROUNDVARIABLESIMAGES_H_